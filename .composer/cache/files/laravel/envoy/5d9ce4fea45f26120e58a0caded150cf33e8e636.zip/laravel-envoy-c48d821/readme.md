# Laravel Envoy

Elegant SSH tasks for PHP.

Official documentation [is located here](https://laravel.com/docs/envoy).
