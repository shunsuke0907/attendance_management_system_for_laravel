<?php

class TestController
{

    public function validate(TestForm $form)
    {

    }
    
}