<?php

namespace Kris\LaravelFormBuilder\Traits;

trait ValidatesWhenResolved
{
    //
}