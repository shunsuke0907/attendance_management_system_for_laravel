<?php

namespace Symfony\Component\VarDumper\Tests\Fixtures;

class NotLoadableClass extends NotLoadableClass
{
}
